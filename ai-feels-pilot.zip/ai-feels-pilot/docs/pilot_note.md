# Pilot note: emotion in LLM policy outputs

*Sima Soy, [date]. Feasibility pilot. Two pages maximum.*

## 1. Question
How do LLMs express and frame emotions in response to politically relevant prompts, and how does this change under different prompting conditions?

## 2. What I did
- [N] prompts (4 topics × 5 tasks × 5 conditions), [N] models, [N] samples each: [N] outputs, collected [dates].
- Automated coding with a dictionary and an LLM coder (model: [ ]).
- Human coding of [N] outputs, [N] double-coded.

## 3. What I found (preliminary)
**RQ1 Presence.** [One or two sentences. Which emotions appear most, and in which tasks?]

**RQ2 Conditions.** [One or two sentences. Which conditions shift which emotions? Does "neutral" differ from baseline?]

**RQ3 Measurement.** [One or two sentences. Where do human and automated coding agree or disagree? Are there fear/anxiety or anger/moral concern substitutions?]

[Insert one figure: results/figures/rq2_effects_vs_baseline_llm.png]

## 4. What surprised me
[One honest observation from reading the outputs yourself. This is often the most convincing part.]

## 5. Limitations
[Sample size, English only, researcher-written prompts, single primary coder, model versions.]

## 6. What the full project would do differently
[Real policy prompts, multiple languages, validated measurement, link to effects on policymakers.]
