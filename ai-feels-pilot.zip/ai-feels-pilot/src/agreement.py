"""RQ3: do human coding, the LLM coder and the dictionary see the same emotions?

Compares, per emotion:
  - presence (0 vs >0): Cohen's kappa
  - intensity (0-3): Krippendorff's alpha, ordinal
  - dictionary rate vs human intensity: Spearman rho
and for the dominant frame: Cohen's kappa.

It also builds a "substitution" table: when the human coder marks an emotion
the machine misses, which emotion did the machine code instead? This is where
overlap between e.g. fear and anxiety shows up.

Usage:
    python src/agreement.py --coder data/coding/coded_A.csv [--coder2 data/coding/coded_B.csv]
    python src/agreement.py --mock
Output: results/agreement.csv, results/substitutions.csv
"""
import argparse
from pathlib import Path

import krippendorff
import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.metrics import cohen_kappa_score

from common import DATA, EMOTIONS, RESULTS, read_jsonl


def alpha(a, b):
    data = np.array([a, b], dtype=float)
    if np.nanstd(data) == 0:
        return np.nan
    return krippendorff.alpha(reliability_data=data, level_of_measurement="ordinal",
                              value_domain=[0, 1, 2, 3])


def kappa(a, b):
    return np.nan if len(set(a) | set(b)) < 2 else cohen_kappa_score(a, b)


def compare(df, x, y, label):
    rows = []
    for e in EMOTIONS:
        d = df[[f"{x}{e}", f"{y}{e}"]].dropna()
        a, b = d.iloc[:, 0].astype(int), d.iloc[:, 1].astype(int)
        rows.append({"comparison": label, "emotion": e, "n": len(d),
                     "prevalence_x": round((a > 0).mean(), 3),
                     "prevalence_y": round((b > 0).mean(), 3),
                     "kappa_presence": round(kappa(a > 0, b > 0), 3),
                     "alpha_intensity": round(alpha(a, b), 3)})
    return rows


def make_mock_coders(key, outdir):
    """Fake human codes derived from the dictionary + noise, for pipeline tests only."""
    from lexicon import score
    recs = {r["output_id"]: r for r in read_jsonl(DATA / "mock" / "outputs.jsonl")}
    for name, seed in [("A", 1), ("B", 2)]:
        rng = np.random.default_rng(seed)
        rows = []
        for _, k in key.iterrows():
            if name == "B" and not k["double_code"]:
                continue
            s = score(recs[k["output_id"]]["response"])
            row = {"item_id": k["item_id"]}
            for e in EMOTIONS:
                row[e] = int(np.clip(s[f"lex_{e}"] + rng.choice([-1, 0, 0, 0, 0, 1]), 0, 3))
            # simulate the known fear/anxiety confusion
            if row["fear"] and rng.random() < .3:
                row["anxiety"], row["fear"] = max(row["anxiety"], row["fear"]), 0
            row["dominant_frame"] = s["lex_frame"] if s["lex_frame"] != "none" else "structural"
            rows.append(row)
        pd.DataFrame(rows).to_csv(outdir / f"coded_{name}.csv", index=False)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--coder", help="filled-in coding sheet, coder A")
    ap.add_argument("--coder2", help="filled-in coding sheet, coder B (double-coded items)")
    ap.add_argument("--mock", action="store_true")
    args = ap.parse_args()

    coding_dir = DATA / ("mock" if args.mock else "coding")
    res_dir = RESULTS / "mock" if args.mock else RESULTS
    key = pd.read_csv(coding_dir / "coding_key.csv")
    if args.mock:
        make_mock_coders(key, coding_dir)
        args.coder, args.coder2 = coding_dir / "coded_A.csv", coding_dir / "coded_B.csv"
    if not args.coder:
        raise SystemExit("Pass --coder path/to/coded_A.csv")

    human = pd.read_csv(args.coder).rename(columns={e: f"h_{e}" for e in EMOTIONS})
    human = human.rename(columns={"dominant_frame": "h_frame"})
    lex = pd.read_csv(res_dir / "lexicon_scores.csv")
    llm = pd.DataFrame(read_jsonl(res_dir / "llm_codes.jsonl"))
    df = key.merge(human, on="item_id").merge(lex, on="output_id").merge(llm, on="output_id")
    print(f"{len(df)} items with human, dictionary and LLM codes")

    rows = compare(df, "h_", "llm_", "human vs LLM coder")
    rows += compare(df, "h_", "lex_", "human vs dictionary")
    if args.coder2 and Path(args.coder2).exists():
        h2 = pd.read_csv(args.coder2).rename(columns={e: f"h2_{e}" for e in EMOTIONS})
        d2 = df.merge(h2, on="item_id")
        rows += compare(d2, "h_", "h2_", "human A vs human B")
    out = pd.DataFrame(rows)

    rho = {e: spearmanr(df[f"h_{e}"], df[f"lex_{e}_per100"]).statistic for e in EMOTIONS}
    out.loc[out.comparison == "human vs dictionary", "spearman_rate"] = \
        out.loc[out.comparison == "human vs dictionary", "emotion"].map(rho).round(3)
    out.to_csv(res_dir / "agreement.csv", index=False)

    frame_rows = [
        {"comparison": "human vs LLM coder", "frame_kappa": kappa(df.h_frame, df.llm_frame)},
        {"comparison": "human vs dictionary", "frame_kappa": kappa(df.h_frame, df.lex_frame)},
    ]
    pd.DataFrame(frame_rows).round(3).to_csv(res_dir / "agreement_frames.csv", index=False)

    # substitutions: human says X present, LLM says X absent -> what did the LLM code instead?
    sub = pd.DataFrame(0, index=EMOTIONS, columns=EMOTIONS + ["nothing"])
    for _, r in df.iterrows():
        for e in EMOTIONS:
            if r[f"h_{e}"] > 0 and r[f"llm_{e}"] == 0:
                others = [o for o in EMOTIONS if o != e and r[f"llm_{o}"] > 0 and r[f"h_{o}"] == 0]
                for o in others or ["nothing"]:
                    sub.loc[e, o] += 1
    sub.index.name = "human_coded"
    sub.to_csv(res_dir / "substitutions.csv")

    pd.set_option("display.width", 140)
    print(out.to_string(index=False))
    print(pd.DataFrame(frame_rows).round(3).to_string(index=False))
    print(f"-> {res_dir}")


if __name__ == "__main__":
    main()
