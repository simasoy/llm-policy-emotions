"""Send every prompt to every model, with repetitions, and store the raw outputs.

Usage:
    python src/generate.py                      # all models in models.yaml
    python src/generate.py --models claude gpt  # a subset
    python src/generate.py --limit 20           # quick test on the first 20 prompts
    python src/generate.py --mock               # fake outputs to test the pipeline

Output: data/raw/outputs.jsonl (one JSON record per response).
Safe to stop and restart: responses already collected are skipped.
"""
import argparse
import datetime as dt
import random

import pandas as pd

from common import DATA, PROMPTS, append_jsonl, chat, load_yaml, read_jsonl
from mock import mock_response


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--models", nargs="*", help="model ids to run (default: all)")
    ap.add_argument("--limit", type=int, help="only the first N prompts")
    ap.add_argument("--mock", action="store_true", help="generate fake outputs, no API calls")
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    cfg = load_yaml("models.yaml")
    settings = cfg["settings"]
    models = [m for m in cfg["models"] if not args.models or m["id"] in args.models]
    prompts = pd.read_csv(PROMPTS / "prompt_matrix.csv")
    if args.limit:
        prompts = prompts.head(args.limit)

    out = args.out or (DATA / ("mock" if args.mock else "raw") / "outputs.jsonl")
    done = {(r["prompt_id"], r["model_id"], r["rep"]) for r in read_jsonl(out)}

    jobs = [(p, m, rep) for _, p in prompts.iterrows() for m in models
            for rep in range(settings["repetitions"])
            if (p["prompt_id"], m["id"], rep) not in done]
    random.Random(42).shuffle(jobs)  # spread prompts over time so drift does not align with conditions
    print(f"{len(jobs)} responses to collect ({len(done)} already done) -> {out}")

    for i, (p, m, rep) in enumerate(jobs, 1):
        if args.mock:
            text = mock_response(p, m["id"], rep)
        else:
            try:
                text = chat(m, p["prompt_text"], settings["temperature"], settings["max_tokens"])
            except Exception as e:  # keep going; failed items can be re-run later
                print(f"  FAILED {p['prompt_id']} {m['id']} rep{rep}: {e}")
                continue
        append_jsonl(out, {
            "output_id": f"{p['prompt_id']}__{m['id']}__r{rep}",
            "prompt_id": p["prompt_id"], "topic": p["topic"], "task": p["task"],
            "genre": p["genre"], "user_role": p["user_role"], "condition": p["condition"],
            "lang": p["lang"], "model_id": m["id"], "model": m.get("model", "mock"),
            "rep": rep, "temperature": settings["temperature"],
            "prompt_text": p["prompt_text"], "response": text,
            "mock": bool(args.mock),
            "collected_at": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
        })
        if i % 250 == 0:
            print(f"  {i}/{len(jobs)}")
    print("done")


if __name__ == "__main__":
    main()
