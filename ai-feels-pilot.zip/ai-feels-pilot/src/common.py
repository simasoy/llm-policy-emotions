"""Shared constants, paths and a minimal LLM client (no SDKs needed)."""
import json
import os
import time
from pathlib import Path

import requests
import yaml

ROOT = Path(__file__).resolve().parents[1]
PROMPTS = ROOT / "prompts"
DATA = ROOT / "data"
RESULTS = ROOT / "results"

EMOTIONS = ["fear", "anxiety", "anger", "hope", "enthusiasm", "compassion", "moral_concern"]
FRAMES = ["threat", "structural", "moral", "human_interest", "opportunity"]
CONDITIONS = ["baseline", "neutral", "empathy", "risk", "solution"]


def load_yaml(name):
    with open(PROMPTS / name, encoding="utf-8") as f:
        return yaml.safe_load(f)


def read_jsonl(path):
    path = Path(path)
    if not path.exists():
        return []
    with open(path, encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def append_jsonl(path, record):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")


def chat(cfg, prompt, temperature, max_tokens, system=None, retries=4):
    """Send one prompt to a model described by a models.yaml entry. Returns text."""
    key_env = cfg.get("api_key_env")
    key = os.environ.get(key_env) if key_env else None
    if key_env and not key:
        raise RuntimeError(f"Missing environment variable {key_env}")

    for attempt in range(retries):
        try:
            if cfg["provider"] == "anthropic":
                body = {
                    "model": cfg["model"],
                    "max_tokens": max_tokens,
                    "temperature": temperature,
                    "messages": [{"role": "user", "content": prompt}],
                }
                if system:
                    body["system"] = system
                r = requests.post(
                    "https://api.anthropic.com/v1/messages",
                    headers={"x-api-key": key, "anthropic-version": "2023-06-01",
                             "content-type": "application/json"},
                    json=body, timeout=120)
                r.raise_for_status()
                return "".join(b.get("text", "") for b in r.json()["content"])

            if cfg["provider"] == "openai_compatible":
                messages = ([{"role": "system", "content": system}] if system else []) + \
                           [{"role": "user", "content": prompt}]
                headers = {"content-type": "application/json"}
                if key:
                    headers["authorization"] = f"Bearer {key}"
                r = requests.post(
                    cfg["base_url"].rstrip("/") + "/chat/completions",
                    headers=headers,
                    json={"model": cfg["model"], "messages": messages,
                          "temperature": temperature, "max_tokens": max_tokens},
                    timeout=120)
                r.raise_for_status()
                return r.json()["choices"][0]["message"]["content"]

            raise ValueError(f"Unknown provider {cfg['provider']}")
        except (requests.RequestException, KeyError) as e:
            if attempt == retries - 1:
                raise
            wait = 2 ** attempt * 5
            print(f"  retry in {wait}s ({e})")
            time.sleep(wait)
