"""Automated measure 1: a transparent dictionary baseline.

Counts cue words for each emotion and frame (see codebook.md) and reports
hits per 100 words, plus a 0-3 intensity score so it can be compared with
human coding. Dictionaries are crude on purpose: they are the kind of tool
much political text analysis still relies on, and RQ3 asks how far they
agree with human and interpretive readings of LLM text.

Usage:
    python src/lexicon.py [--mock]
Output: results/lexicon_scores.csv
"""
import argparse
import re

import pandas as pd

from common import DATA, EMOTIONS, FRAMES, RESULTS, read_jsonl

# Seed lexicon v0.1. Entries ending in * match any continuation.
LEXICON = {
    "fear": ["threat*", "danger*", "at risk", "crisis", "catastroph*", "alarming", "jeopard*",
             "devastat*", "collapse", "cannot afford to wait", "emergenc*"],
    "anxiety": ["worr*", "uncertain*", "anxi*", "unease", "uneasy", "concern*", "apprehens*",
                "nervous", "unclear", "unsettl*"],
    "anger": ["unacceptable", "outrag*", "fail*", "betray*", "disgrace*", "scandal*",
              "enough is enough", "furious", "anger", "angry", "shameful"],
    "hope": ["hope*", "better future", "within reach", "together we", "can build", "brighter",
             "opportunit*", "optimis*", "look forward", "progress"],
    "enthusiasm": ["proud", "pride", "bold", "exciting", "excited", "ambitious", "seize",
                   "thrilled", "energ*", "inspir*"],
    "compassion": ["struggl*", "vulnerable", "hardship*", "dignity", "suffer*", "left behind",
                   "compassion*", "empath*", "care for", "support them"],
    "moral_concern": ["fair*", "unfair*", "justice", "injustice", "responsib*", "obligation*",
                      "rights", "duty", "we owe", "moral*", "ethical"],
}

FRAME_LEXICON = {
    "threat": ["threat*", "crisis", "danger*", "risk*", "emergenc*"],
    "structural": ["structural", "market*", "supply", "demand", "capacity", "system*",
                   "cost*", "budget*", "fiscal", "econom*", "trade-off*"],
    "moral": ["fair*", "justice", "rights", "responsib*", "duty", "moral*"],
    "human_interest": ["famil*", "young people", "children", "resident*", "pensioner*",
                       "people who", "stories", "neighbour*"],
    "opportunity": ["opportunit*", "innovat*", "chance", "benefit*", "build", "future"],
}


def compile_terms(terms):
    parts = []
    for t in terms:
        esc = re.escape(t.rstrip("*"))
        parts.append(rf"\b{esc}\w*" if t.endswith("*") else rf"\b{esc}\b")
    return re.compile("|".join(parts), re.IGNORECASE)


PATTERNS = {k: compile_terms(v) for k, v in LEXICON.items()}
FRAME_PATTERNS = {k: compile_terms(v) for k, v in FRAME_LEXICON.items()}


def to_intensity(hits):
    """Map raw hit counts to the codebook's 0-3 scale. Thresholds are a documented guess."""
    return 0 if hits == 0 else 1 if hits == 1 else 2 if hits <= 3 else 3


def score(text):
    text = text.replace("[MOCK OUTPUT]", "")
    n_words = max(len(text.split()), 1)
    row = {"n_words": n_words}
    for emo, pat in PATTERNS.items():
        hits = len(pat.findall(text))
        row[f"lex_{emo}_hits"] = hits
        row[f"lex_{emo}_per100"] = round(100 * hits / n_words, 3)
        row[f"lex_{emo}"] = to_intensity(hits)
    frame_hits = {f: len(p.findall(text)) for f, p in FRAME_PATTERNS.items()}
    row["lex_frame"] = max(frame_hits, key=frame_hits.get) if any(frame_hits.values()) else "none"
    return row


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mock", action="store_true")
    args = ap.parse_args()
    sub = "mock" if args.mock else "raw"
    recs = read_jsonl(DATA / sub / "outputs.jsonl")
    if not recs:
        raise SystemExit(f"No outputs in data/{sub}/outputs.jsonl. Run generate.py first.")

    rows = [{"output_id": r["output_id"], **score(r["response"])} for r in recs]
    outdir = RESULTS / "mock" if args.mock else RESULTS
    outdir.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(outdir / "lexicon_scores.csv", index=False)
    print(f"Scored {len(rows)} outputs -> {outdir / 'lexicon_scores.csv'}")


if __name__ == "__main__":
    main()
