"""Draw a stratified, blinded sample of outputs for human coding.

The coding sheet shows the text only. Model, condition, topic and prompt are
kept in a separate key file so coders cannot be influenced by them.

Usage:
    python src/sample_for_coding.py --n 60 [--double 0.2] [--mock]
Outputs (in data/coding/):
    coding_sheet.csv   what coders fill in (open in Excel / Google Sheets)
    coding_key.csv     item_id -> output_id and metadata (do not show to coders)
"""
import argparse

import pandas as pd

from common import DATA, EMOTIONS, read_jsonl


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=60)
    ap.add_argument("--double", type=float, default=0.2, help="share to be double-coded")
    ap.add_argument("--seed", type=int, default=2026)
    ap.add_argument("--mock", action="store_true")
    args = ap.parse_args()
    sub = "mock" if args.mock else "raw"
    df = pd.DataFrame(read_jsonl(DATA / sub / "outputs.jsonl"))

    # equal numbers per condition, spread across topics and tasks within each
    per_cond = args.n // df["condition"].nunique()
    parts = []
    for _, g in df.groupby("condition"):
        g = g.sample(frac=1, random_state=args.seed)
        g = g.groupby(["topic", "task"], group_keys=False).head(1)  # one per cell first
        parts.append(g.head(per_cond))
    sample = pd.concat(parts).sample(frac=1, random_state=args.seed).reset_index(drop=True)
    sample["item_id"] = [f"item_{i:03d}" for i in range(1, len(sample) + 1)]
    n_double = round(len(sample) * args.double)
    sample["double_code"] = [i < n_double for i in range(len(sample))]

    outdir = DATA / ("mock" if args.mock else "coding")
    outdir.mkdir(parents=True, exist_ok=True)
    key_cols = ["item_id", "output_id", "model_id", "topic", "task", "genre", "condition",
                "double_code"]
    sample[key_cols].to_csv(outdir / "coding_key.csv", index=False)

    sheet = sample[["item_id", "double_code", "response"]].rename(columns={"response": "text"})
    sheet["text"] = sheet["text"].str.replace("[MOCK OUTPUT] ", "", regex=False)
    for e in EMOTIONS:
        sheet[e] = ""            # 0-3
        sheet[f"{e}_mode"] = ""  # expressed / attributed / both
        sheet[f"{e}_target"] = ""
    for c in ["dominant_frame", "urgency", "balance_signal", "overlap_flag", "notes"]:
        sheet[c] = ""
    sheet.to_csv(outdir / "coding_sheet.csv", index=False)
    print(f"{len(sheet)} items ({n_double} to double-code) -> {outdir}")
    print(sample["condition"].value_counts().to_string())


if __name__ == "__main__":
    main()
