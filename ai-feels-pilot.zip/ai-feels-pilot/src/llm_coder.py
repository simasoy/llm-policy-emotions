"""Automated measure 2: an LLM applies the codebook.

The coder model sees the response only (not the prompt or condition), and
returns the codebook's variables as JSON. It is compared with human coding
in agreement.py.

Usage:
    python src/llm_coder.py [--limit N] [--mock]
Output: results/llm_codes.jsonl
"""
import argparse
import json
import random
import re

from common import (DATA, EMOTIONS, FRAMES, RESULTS, append_jsonl, chat, load_yaml,
                    read_jsonl)

SYSTEM = "You are a careful content analyst coding political texts. You answer with JSON only."

INSTRUCTIONS = f"""Code the TEXT below using this codebook.

EMOTIONS: for each of {EMOTIONS}, give intensity 0-3
(0 absent, 1 implicit or mild, 2 explicit, 3 dominant).
- fear: concrete threat of harm or loss
- anxiety: diffuse worry or uncertainty
- anger: blame or indignation at a responsible agent
- hope: expectation that things can improve
- enthusiasm: high-energy pride, excitement, determination
- compassion: concern for others' suffering or hardship
- moral_concern: appeal to fairness, rights or duty
For each emotion with intensity > 0 also give:
- mode: "expressed" (in the text's own voice), "attributed" (reported as held by others), or "both"
- target: "speaker", "public", "affected", "opponents" or "model"

FRAMING:
- dominant_frame: one of {FRAMES}
- urgency: 0 (none), 1 (some), 2 (immediate action needed)
- balance_signal: true if the text explicitly performs neutrality or balance

Return exactly this JSON shape:
{{"emotions": {{"fear": {{"intensity": 0, "mode": null, "target": null}}, ...}},
  "dominant_frame": "...", "urgency": 0, "balance_signal": false}}

TEXT:
"""


def parse(raw):
    m = re.search(r"\{.*\}", raw, re.DOTALL)
    return json.loads(m.group(0))


def mock_code(text, rng):
    from lexicon import score
    s = score(text)
    emotions = {}
    for e in EMOTIONS:
        v = max(0, min(3, s[f"lex_{e}"] + rng.choice([-1, 0, 0, 0, 1])))
        emotions[e] = {"intensity": v, "mode": "expressed" if v else None,
                       "target": "public" if v else None}
    return {"emotions": emotions, "dominant_frame": s["lex_frame"] if s["lex_frame"] != "none"
            else "structural", "urgency": rng.randint(0, 2), "balance_signal": rng.random() < .4}


def flatten(output_id, coded):
    row = {"output_id": output_id}
    for e in EMOTIONS:
        d = coded.get("emotions", {}).get(e, {}) or {}
        row[f"llm_{e}"] = int(d.get("intensity") or 0)
        row[f"llm_{e}_mode"] = d.get("mode")
        row[f"llm_{e}_target"] = d.get("target")
    row["llm_frame"] = coded.get("dominant_frame")
    row["llm_urgency"] = coded.get("urgency")
    row["llm_balance"] = coded.get("balance_signal")
    return row


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--limit", type=int)
    ap.add_argument("--mock", action="store_true")
    args = ap.parse_args()
    sub = "mock" if args.mock else "raw"
    recs = read_jsonl(DATA / sub / "outputs.jsonl")[: args.limit]
    out = (RESULTS / "mock" if args.mock else RESULTS) / "llm_codes.jsonl"
    done = {r["output_id"] for r in read_jsonl(out)}
    coder = load_yaml("models.yaml")["coder"]
    rng = random.Random(7)

    todo = [r for r in recs if r["output_id"] not in done]
    print(f"{len(todo)} outputs to code -> {out}")
    for i, r in enumerate(todo, 1):
        try:
            coded = mock_code(r["response"], rng) if args.mock else parse(
                chat(coder, INSTRUCTIONS + r["response"], 0, 600, system=SYSTEM))
        except Exception as e:
            print(f"  FAILED {r['output_id']}: {e}")
            continue
        append_jsonl(out, flatten(r["output_id"], coded))
        if i % 250 == 0:
            print(f"  {i}/{len(todo)}")
    print("done")


if __name__ == "__main__":
    main()
