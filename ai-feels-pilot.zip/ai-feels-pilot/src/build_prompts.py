"""Expand topics x tasks x conditions into the full prompt matrix.

Output: prompts/prompt_matrix.csv
"""
import pandas as pd

from common import PROMPTS, load_yaml


def main():
    topics = load_yaml("topics.yaml")["topics"]
    tasks = load_yaml("tasks.yaml")["tasks"]
    conditions = load_yaml("conditions.yaml")["conditions"]

    rows = []
    for t in topics:
        for k in tasks:
            base = k["template"].format(issue=t["issue"], ministry=t["ministry"]).strip()
            for c in conditions:
                text = base if not c["instruction"] else f"{base} {c['instruction'].strip()}"
                rows.append({
                    "prompt_id": f"{t['id']}__{k['id']}__{c['id']}",
                    "topic": t["id"],
                    "topic_charge": t["charge"],
                    "task": k["id"],
                    "genre": k["genre"],
                    "user_role": k["user_role"],
                    "condition": c["id"],
                    "lang": "en",
                    "prompt_text": text,
                })

    df = pd.DataFrame(rows)
    out = PROMPTS / "prompt_matrix.csv"
    df.to_csv(out, index=False)
    print(f"{len(df)} prompts "
          f"({len(topics)} topics x {len(tasks)} tasks x {len(conditions)} conditions) -> {out}")


if __name__ == "__main__":
    main()
