"""RQ1 (presence) and RQ2 (conditions).

RQ1: how often each emotion appears, by task, topic and model.
RQ2: how each prompting condition shifts emotional intensity relative to the
     baseline (no instruction). 95% CIs from a cluster bootstrap over prompts,
     because repeated samples of the same prompt are not independent.

Usage:
    python src/analyze.py [--source llm|lexicon] [--mock]
Outputs in results/: rq1_*.csv, rq2_*.csv, and figures/*.png
"""
import argparse

import matplotlib
import numpy as np
import pandas as pd

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.colors import LinearSegmentedColormap  # noqa: E402

from common import CONDITIONS, DATA, EMOTIONS, FRAMES, RESULTS, read_jsonl  # noqa: E402

INK, INK2, GRID, BLUE = "#0b0b0b", "#52514e", "#e4e3df", "#2a78d6"
SEQ = LinearSegmentedColormap.from_list("seq", ["#f4f8fd", "#9cc3ef", "#2a78d6", "#123f7a"])
plt.rcParams.update({"font.size": 9, "text.color": INK, "axes.labelcolor": INK2,
                     "xtick.color": INK2, "ytick.color": INK2, "axes.edgecolor": GRID})


def load(source, mock):
    sub = "mock" if mock else "raw"
    res = RESULTS / "mock" if mock else RESULTS
    meta = pd.DataFrame(read_jsonl(DATA / sub / "outputs.jsonl")).drop(columns=["response"])
    if source == "llm":
        codes = pd.DataFrame(read_jsonl(res / "llm_codes.jsonl"))
        prefix, frame_col = "llm_", "llm_frame"
    else:
        codes = pd.read_csv(res / "lexicon_scores.csv")
        prefix, frame_col = "lex_", "lex_frame"
    df = meta.merge(codes, on="output_id")
    df = df.rename(columns={f"{prefix}{e}": e for e in EMOTIONS} | {frame_col: "frame"})
    return df, res


def heatmap(table, title, path, fmt="{:.0%}"):
    fig, ax = plt.subplots(figsize=(1.1 + 0.9 * table.shape[1], 0.8 + 0.42 * table.shape[0]))
    ax.pcolormesh(np.arange(table.shape[1] + 1) - .5, np.arange(table.shape[0] + 1) - .5, table.values, edgecolors="white", linewidth=2, cmap=SEQ, vmin=0, vmax=max(table.values.max(), 1e-9))
    ax.invert_yaxis()
    ax.set_xticks(range(table.shape[1]), [c.replace("_", "\n") for c in table.columns])
    ax.set_yticks(range(table.shape[0]), [i.replace("_", " ") for i in table.index])
    for (i, j), v in np.ndenumerate(table.values):
        rgba = SEQ(v / max(table.values.max(), 1e-9))
        lum = 0.2126 * rgba[0] + 0.7152 * rgba[1] + 0.0722 * rgba[2]
        ax.text(j, i, fmt.format(v), ha="center", va="center", fontsize=8,
                color="white" if lum < 0.5 else INK)
    ax.tick_params(length=0)
    for s in ax.spines.values():
        s.set_visible(False)
    ax.set_title(title, loc="left", fontsize=10, color=INK, pad=10)
    fig.tight_layout()
    fig.savefig(path, dpi=200)
    plt.close(fig)


def cluster_boot_diff(df, emo, cond, n_boot=2000, seed=0):
    """Mean(cond) - mean(baseline), resampling base prompts (topic x task) as clusters."""
    rng = np.random.default_rng(seed)
    d = df[df.condition.isin(["baseline", cond])].copy()
    d["cluster"] = d.topic + "__" + d.task
    means = d.groupby(["cluster", "condition"])[emo].mean().unstack()
    means = means.dropna()
    diffs = (means[cond] - means["baseline"]).values
    point = diffs.mean()
    boots = [rng.choice(diffs, len(diffs), replace=True).mean() for _ in range(n_boot)]
    lo, hi = np.percentile(boots, [2.5, 97.5])
    return point, lo, hi


def rq2_plot(effects, path, source):
    conds = [c for c in CONDITIONS if c != "baseline"]
    fig, axes = plt.subplots(1, len(conds), figsize=(2.3 * len(conds) + 1, 3.2), sharey=True,
                             sharex=True)
    lim = max(effects[["lo", "hi"]].abs().max().max(), 0.5) * 1.1
    for ax, c in zip(axes, conds):
        e = effects[effects.condition == c].set_index("emotion").loc[EMOTIONS[::-1]]
        y = np.arange(len(e))
        ax.axvline(0, color=INK2, lw=1)
        ax.hlines(y, e.lo, e.hi, color=BLUE, lw=2)
        ax.scatter(e["diff"], y, s=36, color=BLUE, edgecolor="white", linewidth=1.5, zorder=3)
        ax.set_yticks(y, [i.replace("_", " ") for i in e.index])
        ax.set_xlim(-lim, lim)
        ax.set_title(c, fontsize=9, color=INK)
        ax.grid(axis="x", color=GRID, lw=0.8)
        ax.set_axisbelow(True)
        ax.tick_params(length=0)
        for s in ["top", "right", "left"]:
            ax.spines[s].set_visible(False)
    fig.supxlabel("Change in mean intensity vs baseline (0-3 scale), 95% CI", fontsize=8,
                  color=INK2)
    label = {"llm": "LLM coder", "lexicon": "dictionary"}[source]
    fig.suptitle(f"RQ2: emotional intensity by prompting condition ({label})",
                 x=0.01, ha="left", fontsize=10, color=INK)
    fig.tight_layout()
    fig.savefig(path, dpi=200)
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", choices=["llm", "lexicon"], default="llm")
    ap.add_argument("--mock", action="store_true")
    args = ap.parse_args()
    df, res = load(args.source, args.mock)
    figs = res / "figures"
    figs.mkdir(parents=True, exist_ok=True)
    tag = f"_{args.source}"
    print(f"{len(df)} coded outputs, source = {args.source}{' (MOCK)' if args.mock else ''}")

    present = df[EMOTIONS].gt(0)

    # RQ1: presence
    overall = present.mean().rename("share_present").to_frame()
    overall["mean_intensity"] = df[EMOTIONS].mean()
    overall.round(3).to_csv(res / f"rq1_overall{tag}.csv")
    by = {}
    for col in ["task", "topic", "model_id"]:
        t = present.groupby(df[col]).mean().T
        t.round(3).to_csv(res / f"rq1_by_{col}{tag}.csv")
        by[col] = t
    heatmap(by["task"], "RQ1: share of outputs expressing each emotion, by task",
            figs / f"rq1_emotion_by_task{tag}.png")

    # RQ2: conditions
    means = df.groupby("condition")[EMOTIONS].mean().T[CONDITIONS]
    means.round(3).to_csv(res / f"rq2_mean_intensity{tag}.csv")
    heatmap(means, "RQ2: mean emotional intensity (0-3) by condition",
            figs / f"rq2_intensity_by_condition{tag}.png", fmt="{:.2f}")
    rows = []
    for c in CONDITIONS[1:]:
        for e in EMOTIONS:
            d, lo, hi = cluster_boot_diff(df, e, c)
            rows.append({"condition": c, "emotion": e, "diff": d, "lo": lo, "hi": hi})
    effects = pd.DataFrame(rows)
    effects.round(3).to_csv(res / f"rq2_effects_vs_baseline{tag}.csv", index=False)
    rq2_plot(effects, figs / f"rq2_effects_vs_baseline{tag}.png", args.source)

    # framing by condition
    frames = pd.crosstab(df.frame, df.condition, normalize="columns")
    frames = frames.reindex(columns=CONDITIONS)
    frames.round(3).to_csv(res / f"rq2_frames_by_condition{tag}.csv")
    heatmap(frames.fillna(0), "Dominant frame by condition (share of outputs)",
            figs / f"rq2_frames_by_condition{tag}.png")

    print(overall.round(2).to_string())
    print(f"-> {res}")


if __name__ == "__main__":
    main()
