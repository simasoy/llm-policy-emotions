"""Fake data for testing the pipeline end to end without API calls.

Nothing produced here is a result. Mock records carry "mock": true and are
written to data/mock/ and results/mock/, never to data/raw/ or results/.
"""
import random

SENTENCES = {
    "neutral": [
        "The evidence points in several directions.",
        "There are trade-offs between cost and effectiveness.",
        "Available data suggest a mixed picture.",
        "It is important to consider all perspectives.",
    ],
    "fear": ["This is a serious threat that puts communities at risk.",
             "Without action, we face a crisis."],
    "anxiety": ["Many people are uncertain and worried about the future.",
                "There is growing unease about what comes next."],
    "anger": ["It is unacceptable that previous governments failed to act."],
    "hope": ["Together we can build a better future.",
             "A fairer system is within reach."],
    "enthusiasm": ["I am proud of this bold and ambitious plan."],
    "compassion": ["Families who are struggling deserve our support and dignity.",
                   "We must not leave vulnerable people behind."],
    "moral_concern": ["We have a responsibility to act fairly.",
                      "This is a question of justice and rights."],
}

# how likely each emotion is to appear under each condition (mock only)
BIAS = {
    "baseline": {"hope": .3, "anxiety": .3, "compassion": .2},
    "neutral": {"anxiety": .2},
    "empathy": {"compassion": .8, "anxiety": .5, "hope": .3, "moral_concern": .3},
    "risk": {"fear": .7, "anxiety": .7, "anger": .2},
    "solution": {"hope": .8, "enthusiasm": .4},
}
GENRE_BOOST = {"persuasive": 1.4, "relational": 1.2, "analytic": 0.7}


def mock_response(p, model_id, rep):
    rng = random.Random(f"{p['prompt_id']}{model_id}{rep}")
    parts = rng.sample(SENTENCES["neutral"], 2)
    boost = GENRE_BOOST[p["genre"]] * (1.2 if model_id == "claude" else 1.0)
    for emo, prob in BIAS[p["condition"]].items():
        if rng.random() < min(prob * boost, 0.95):
            parts.append(rng.choice(SENTENCES[emo]))
    for emo in ["anger", "moral_concern", "enthusiasm"]:
        if rng.random() < 0.08:
            parts.append(rng.choice(SENTENCES[emo]))
    rng.shuffle(parts)
    return "[MOCK OUTPUT] " + " ".join(parts)
