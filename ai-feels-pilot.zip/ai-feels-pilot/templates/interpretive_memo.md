# Interpretive memo

**Item ID:**
**Coder:**
**Date:**

## 1. Emotional register
In two or three sentences: what is the overall emotional tone, and how does it build up across the text?

## 2. Feeling rules
What does the text assume about how a politician or civil servant *should* feel and speak about this issue? (e.g. calm competence, visible empathy, controlled indignation)

## 3. Absences
Which emotions would a human author plausibly express here that the text avoids or flattens? Why might that be?

## 4. Emotion and problem definition
How does the emotional register shape what the problem *is*, who is responsible, and what the solution looks like?

## 5. Emotion strategies
Are any recognisable strategies present? (e.g. compassion selection, blaming and shaming, boosting, vilification; see Sanchez Salgado 2021)

## 6. Comparison with the codes
Does this reading agree with the quantitative codes for this item? Where not, what does the code miss?
